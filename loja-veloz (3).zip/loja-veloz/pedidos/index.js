const express = require("express")
const app = express()

app.get("/", (req, res) => {
  res.send("Pedidos funcionando")
})

app.listen(3000, () => {
  console.log("Pedidos na porta 3000")
})