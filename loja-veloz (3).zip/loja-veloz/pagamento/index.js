const express = require("express")
const app = express()

app.get("/", (req, res) => {
  res.send("Pagamento funcionando")
})

app.listen(3000, () => {
  console.log("Pagamento na porta 3000")
})