const express = require("express")
const app = express()

app.get("/", (req, res) => {
  res.send("Estoque funcionando")
})

app.listen(3000, () => {
  console.log("Estoque na porta 3000")
})