provider "aws" {
region = "us-east-1"
}

resource "aws_s3_bucket" "loja_veloz" {
bucket = "loja-veloz-bucket"
}
